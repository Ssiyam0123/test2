import mongoose from "mongoose";
import dotenv from "dotenv";
import User from "../models/user.js";

dotenv.config();

const createAdmin = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);

    console.log("MongoDB Connected");

    // const existingAdmin = await User.findOne({ email : });

    // if (existingAdmin) {
    //   console.log("Admin already exists");
    //   process.exit();
    // }

    const admin = new User({
      username: "suii",
      email: "admin@suiii.com",
      password: "123456", 
      // role: "admin",
    });

    await admin.save();

    console.log("✅ Admin created successfully");
    process.exit();
  } catch (error) {
    console.error("Error creating admin:", error);
    process.exit(1);
  }
};

createAdmin();